import json
import boto3
import re

# Bedrock Runtime 클라이언트
bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')

# Polly 클라이언트 (TTS)
polly = boto3.client('polly', region_name='us-east-1')

# 시스템 프롬프트
SYSTEM_PROMPT = """You are Emma, a friendly AI English tutor making a phone call to help the student practice English conversation.

Guidelines:
- Accent: {accent}
- Difficulty Level: {level}
- Topic: {topic}
- Keep responses natural and conversational (2-3 sentences max)
- Ask follow-up questions to keep the conversation flowing
- Gently correct major grammar errors when appropriate
- Be encouraging and supportive
- Respond in English only

If this is the first message, greet the student warmly and ask them a simple opening question related to the topic."""

# 분석용 프롬프트
ANALYSIS_PROMPT = """Analyze the following English conversation between a student and an AI tutor.
Provide a detailed analysis in JSON format.

Conversation:
{conversation}

Analyze ONLY the student's messages (role: user) and return a JSON object with:

{{
  "cafp_scores": {{
    "complexity": <0-100, vocabulary diversity and sentence structure complexity>,
    "accuracy": <0-100, grammatical correctness>,
    "fluency": <0-100, natural flow and coherence>,
    "pronunciation": <0-100, estimate based on word choice indicating possible pronunciation difficulties>
  }},
  "fillers": {{
    "count": <number of filler words used>,
    "words": [<list of filler words found: um, uh, like, you know, basically, actually, literally, I mean, so, well, etc.>],
    "percentage": <percentage of words that are fillers>
  }},
  "grammar_corrections": [
    {{
      "original": "<original sentence with error>",
      "corrected": "<corrected sentence>",
      "explanation": "<brief explanation in Korean>"
    }}
  ],
  "vocabulary": {{
    "total_words": <total words spoken by student>,
    "unique_words": <unique words count>,
    "advanced_words": [<list of advanced vocabulary used>],
    "suggested_words": [<3-5 advanced words they could have used>]
  }},
  "overall_feedback": "<2-3 sentences of encouraging feedback in Korean>",
  "improvement_tips": [<3 specific tips for improvement in Korean>]
}}

Return ONLY valid JSON, no other text."""

def lambda_handler(event, context):
    """
    Main Lambda handler for AI English conversation
    """
    # CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
    }

    # Handle preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }

    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        action = body.get('action', 'chat')

        if action == 'chat':
            return handle_chat(body, headers)
        elif action == 'tts':
            return handle_tts(body, headers)
        elif action == 'analyze':
            return handle_analyze(body, headers)
        else:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': 'Invalid action'})
            }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)})
        }


def handle_chat(body, headers):
    """
    Handle chat conversation with Bedrock Claude
    """
    messages = body.get('messages', [])
    settings = body.get('settings', {})

    # Build system prompt with settings
    accent_map = {
        'us': 'American English',
        'uk': 'British English',
        'au': 'Australian English',
        'in': 'Indian English'
    }
    level_map = {
        'beginner': 'Beginner (use simple words and short sentences)',
        'intermediate': 'Intermediate (normal conversation level)',
        'advanced': 'Advanced (use complex vocabulary and idioms)'
    }
    topic_map = {
        'business': 'Business and workplace situations',
        'daily': 'Daily life and casual conversation',
        'travel': 'Travel and tourism',
        'interview': 'Job interviews and professional settings'
    }

    system = SYSTEM_PROMPT.format(
        accent=accent_map.get(settings.get('accent', 'us'), 'American English'),
        level=level_map.get(settings.get('level', 'intermediate'), 'Intermediate'),
        topic=topic_map.get(settings.get('topic', 'business'), 'Business')
    )

    # Prepare messages for Claude
    claude_messages = []
    for msg in messages:
        claude_messages.append({
            'role': msg.get('role', 'user'),
            'content': msg.get('content', '')
        })

    # If no messages, start the conversation
    if not claude_messages:
        claude_messages = [{'role': 'user', 'content': 'Hello, let\'s start our English practice session.'}]

    # Call Bedrock Claude
    response = bedrock.invoke_model(
        modelId='anthropic.claude-3-5-sonnet-20241022-v2:0',
        contentType='application/json',
        accept='application/json',
        body=json.dumps({
            'anthropic_version': 'bedrock-2023-05-31',
            'max_tokens': 300,
            'system': system,
            'messages': claude_messages
        })
    )

    # Parse response
    result = json.loads(response['body'].read())
    assistant_message = result['content'][0]['text']

    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps({
            'message': assistant_message,
            'role': 'assistant'
        })
    }


def handle_analyze(body, headers):
    """
    Analyze conversation with AI - fillers, grammar, CAFP scores
    """
    messages = body.get('messages', [])

    if not messages:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': 'No messages to analyze'})
        }

    # Format conversation for analysis
    conversation_text = ""
    for msg in messages:
        role = msg.get('role', msg.get('speaker', 'user'))
        content = msg.get('content', msg.get('en', ''))
        if role in ['user', 'assistant']:
            conversation_text += f"{role}: {content}\n"

    # Quick local analysis for fillers (backup)
    user_messages = [m.get('content', m.get('en', '')) for m in messages
                     if m.get('role', m.get('speaker')) == 'user']
    user_text = ' '.join(user_messages).lower()

    filler_words = ['um', 'uh', 'like', 'you know', 'basically', 'actually',
                    'literally', 'i mean', 'so', 'well', 'kind of', 'sort of']
    found_fillers = []
    for filler in filler_words:
        count = len(re.findall(r'\b' + filler + r'\b', user_text))
        if count > 0:
            found_fillers.extend([filler] * count)

    # Call Claude for detailed analysis
    try:
        prompt = ANALYSIS_PROMPT.format(conversation=conversation_text)

        response = bedrock.invoke_model(
            modelId='anthropic.claude-3-5-sonnet-20241022-v2:0',
            contentType='application/json',
            accept='application/json',
            body=json.dumps({
                'anthropic_version': 'bedrock-2023-05-31',
                'max_tokens': 1500,
                'messages': [{'role': 'user', 'content': prompt}]
            })
        )

        result = json.loads(response['body'].read())
        analysis_text = result['content'][0]['text']

        # Parse JSON from response
        # Find JSON in response (between { and })
        json_match = re.search(r'\{[\s\S]*\}', analysis_text)
        if json_match:
            analysis = json.loads(json_match.group())
        else:
            raise ValueError("No JSON found in response")

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'analysis': analysis,
                'success': True
            })
        }

    except Exception as e:
        print(f"Analysis error: {str(e)}")
        # Return basic analysis if AI fails
        word_count = len(user_text.split())
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'analysis': {
                    'cafp_scores': {
                        'complexity': 70,
                        'accuracy': 75,
                        'fluency': 72,
                        'pronunciation': 78
                    },
                    'fillers': {
                        'count': len(found_fillers),
                        'words': found_fillers,
                        'percentage': round(len(found_fillers) / max(word_count, 1) * 100, 1)
                    },
                    'grammar_corrections': [],
                    'vocabulary': {
                        'total_words': word_count,
                        'unique_words': len(set(user_text.split())),
                        'advanced_words': [],
                        'suggested_words': []
                    },
                    'overall_feedback': '대화를 잘 하셨습니다! 계속 연습하시면 더 좋아질 거예요.',
                    'improvement_tips': [
                        '더 다양한 어휘를 사용해보세요',
                        '문장을 조금 더 길게 만들어보세요',
                        '필러 단어 사용을 줄여보세요'
                    ]
                },
                'success': True,
                'fallback': True
            })
        }


def handle_tts(body, headers):
    """
    Handle text-to-speech with Amazon Polly
    """
    text = body.get('text', '')
    voice = body.get('voice', 'Joanna')  # Default US female voice

    # Voice mapping based on accent/gender
    settings = body.get('settings', {})
    accent = settings.get('accent', 'us')
    gender = settings.get('gender', 'female')

    voice_map = {
        ('us', 'female'): 'Joanna',
        ('us', 'male'): 'Matthew',
        ('uk', 'female'): 'Amy',
        ('uk', 'male'): 'Brian',
        ('au', 'female'): 'Nicole',
        ('au', 'male'): 'Russell',
        ('in', 'female'): 'Aditi',
        ('in', 'male'): 'Aditi',
    }

    voice_id = voice_map.get((accent, gender), 'Joanna')

    # Call Polly
    response = polly.synthesize_speech(
        Text=text,
        OutputFormat='mp3',
        VoiceId=voice_id,
        Engine='neural'
    )

    # Read audio stream and encode as base64
    import base64
    audio_data = response['AudioStream'].read()
    audio_base64 = base64.b64encode(audio_data).decode('utf-8')

    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps({
            'audio': audio_base64,
            'contentType': 'audio/mpeg'
        })
    }
